package ajay.ld37.main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Screen extends Canvas implements Runnable, KeyListener, MouseListener{
	//ImageIO.read(Game.class.getResourceAsStream("/res/loading.png"));
	private static final long serialVersionUID = -572016035490436338L;
	BufferStrategy s;
	BufferedImage world,screenImage;
	
	int targetfps = 60;
	long timeperupdate = 1000/targetfps,last;
	public double delta;
	
	boolean up,down,left,right;
	boolean peek;
	
	Player player;
	ArrayList<Maze> maze = new ArrayList<>();
	ArrayList<Coin> coins = new ArrayList<>();
	int currentmaze = 0;
	int nextmaze = 1;
	
	Random rand = new Random();
	
	int coinamount;
	Endpoint endpoint;
	int checkpoints = 0;
	BufferedImage flag;
	float checkpointangle;
	
	float worldanisize;
	boolean worldani;
	
	Color blue = new Color(135,205,235);
	Color orange = new Color(244, 99, 14);
	
	BufferedImage[] title = new BufferedImage[4];
	BufferedImage end;
	int titlenum = 0;
	boolean next;
	
	boolean loaded;
	
	public Screen(){
		addKeyListener(this);
		addMouseListener(this);
		new Thread(new Runnable() {
			  // The wrapper thread is unnecessary, unless it blocks on the
			  // Clip finishing; see comments.
			    public void run() {
			      try {
			        Clip clip = AudioSystem.getClip();
			        AudioInputStream inputStream = AudioSystem.getAudioInputStream(
			          Main.class.getResourceAsStream("/res/ld37 final.wav"));
			        clip.open(inputStream);
			        clip.loop(clip.LOOP_CONTINUOUSLY);
			        clip.start(); 
			      } catch (Exception e) {
			        System.err.println(e.getMessage());
			      }
			    }
		  }).start();
	}
	
	public void init(){
		loaded = false;
		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if(!loaded) init();
			}
		});
		thread.start();
		
		player = new Player(this);
		
		//maze generation
		maze.add(new Maze(this));
		ArrayList<MazeSquare> bigest = Maze.getNLongestChain(maze.get(0).squares, 1);
		MazeSquare start = bigest.get(rand.nextInt(bigest.size()));
		
		player.x = start.x*64+16;
		player.y = start.y*64+16;
		
		MazeSquare next = bigest.get(rand.nextInt(bigest.size()));
		while(Math.abs(start.x-next.x) < 4 || Math.abs(start.y-next.y) < 4){
			next = bigest.get(rand.nextInt(bigest.size()));
		}
		for(int a=0;a<5;a++){
			Maze nextMaze = new Maze(this);
			while(Maze.getConnected(nextMaze.squares.get(next.y+next.x*getHeight()/32)).size() < 30){
				nextMaze.squares = Maze.generate(this);
			}
			ArrayList<MazeSquare> connectedtonext = Maze.getConnected((nextMaze.squares.get(next.y+next.x*getHeight()/32)));
			boolean good = false;
			while(!good){
				for(MazeSquare square: connectedtonext){
					if(!Maze.getConnected(square).contains(next) && Maze.getConnected(square).size() > 20){
						good = true;
						nextMaze.squares = Maze.generate(this);
						break;
					}
				}
				if(!good){
					nextMaze.squares = Maze.generate(this);
					while(Maze.getConnected(nextMaze.squares.get(next.y+next.x*getHeight()/32)).size() < 30){
						nextMaze.squares = Maze.generate(this);
					}
				}
			}
			maze.add(nextMaze);
			next = Maze.getNLongestChain(nextMaze.squares, 1).get(rand.nextInt(Maze.getNLongestChain(nextMaze.squares, 1).size()));
			while(Math.abs(start.x-next.x) < 4 || Math.abs(start.y-next.y) < 4){
				next = Maze.getNLongestChain(nextMaze.squares, 1).get(rand.nextInt(Maze.getNLongestChain(nextMaze.squares, 1).size()));
			}
		}
		
		endpoint = new Endpoint(next.x, next.y);
		
		for(MazeSquare square: maze.get(0).squares){
			if(rand.nextDouble()>0.95){
				coins.add(new Coin(square.x, square.y));
			}
		}
		
		world = new BufferedImage(getWidth()*2, getHeight()*2, BufferedImage.TYPE_INT_ARGB);
		screenImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
		
		try {
			flag = ImageIO.read(Screen.class.getResourceAsStream("/res/flag.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		loaded = true;
		
		Thread game = new Thread(this);
		game.start();
	}
	public void run() {
		
		try {
			for(int i=0;i<title.length;i++){
				title[i] = ImageIO.read(Screen.class.getResourceAsStream("/res/title" + i + ".png"));
			}
			end = ImageIO.read(Screen.class.getResourceAsStream("/res/end.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		while(!next){
			s = getBufferStrategy();
			if(s!=null){
				Graphics2D g = (Graphics2D) s.getDrawGraphics();
				
				g.drawImage(title[titlenum], 0, 0, null);
				
				s.show();
			}else{
				createBufferStrategy(3);
			}
		}
		next = false;
		
		while(true){
			long now = System.currentTimeMillis();
			long updateLength = now - last;
		    last = now;
			delta = updateLength / ((double)timeperupdate);
			if(delta > 60) delta = 1;
			
			if(checkpoints>=5){
				break;
			}
			
			render();
			player.update(this);
			maze.get(currentmaze).update(this);
			
		}
		
		while(!next){
			s = getBufferStrategy();
			if(s!=null){
				Graphics2D g = (Graphics2D) s.getDrawGraphics();
				
				g.drawImage(end, 0, 0, null);
				
				s.show();
			}else{
				createBufferStrategy(3);
			}
		}
		next = false;
		titlenum = 0;
		checkpoints = 0;
		coinamount = 0;
		init();
	}
	
	public void render(){
		s = getBufferStrategy();
		if(s!=null){
			Graphics2D g3 = (Graphics2D) s.getDrawGraphics();
			
			g3.setColor(orange);
			g3.fillRect(0, 0, getWidth(), getHeight());
			
			Graphics2D g2 = (Graphics2D) screenImage.getGraphics();
			
			g2.setColor(orange);
			g2.fillRect(0, 0, getWidth(), getHeight());
			
			Graphics2D g = (Graphics2D) world.getGraphics();			
			g.setColor(blue);
			g.fillRect(0, 0, getWidth()*2, getHeight()*2);
			
			player.render(g);
			
			maze.get(currentmaze).render(g, this);
			
			endpoint.render(g);
			
			if(worldani){
				worldanisize-=150*delta;
				if(worldanisize<0){
					worldanisize = 0;
					worldani = false;
				}
			}
//			}else{
			g2.drawImage(world, (int) (-player.x+getWidth()/2+player.image.getWidth()/2), (int) (-player.y+getHeight()/2+player.image.getHeight()/2), null);
//			}
			if(worldanisize<getWidth()*2 && !worldani){
				worldanisize+=150*delta;
			}else if(!worldani){
				worldanisize = getWidth()*2;
			}

//			if(peek) maze.get(nextmaze).peek2(g2, g2, this);
			
			g2.setColor(Color.black);
			if(peek) maze.get(nextmaze).peek(g2, this);
			else maze.get(nextmaze).closepeek(g2, this);
			
			
			for(int i=0;i<checkpoints;i++){
				if(checkpointangle<Math.PI*6){
					AffineTransform old = g2.getTransform();
					AffineTransform transform = new AffineTransform();
					transform.rotate(-checkpointangle, 40+i*(flag.getWidth()+15)+flag.getWidth()/2, 20+flag.getHeight()/2);
					g2.setTransform(transform);
					checkpointangle +=0.3*delta;
					g2.drawImage(flag, 40+i*(flag.getWidth()+15), 20, null);
					g.setTransform(old);
				}else{
//					checkpointangle = 0;
					g2.drawImage(flag, 40+i*(flag.getWidth()+15), 20, null);
				}
				
			}
			
			String message = "Coins: " + coinamount;
			g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 50));
			g2.drawString(message, getWidth()/2-g2.getFontMetrics().stringWidth(message)/2, g2.getFont().getSize());
			
			g3.drawImage(screenImage, (int) (getWidth()/2-worldanisize/4), 0, (int) worldanisize/2, getHeight(), null);
			
//			g.dispose();
			s.show();
		}else{
			createBufferStrategy(3);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_D){
			right = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_A){
			left = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_W){
			up = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_S){
			down = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_SHIFT){
			peek = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_SPACE && !peek && player.canMove(this, (int) player.x, (int) player.y, nextmaze)){
			if(maze.size() > currentmaze+1){
				currentmaze++;
				if(maze.size() > nextmaze+1){
					nextmaze++;
				}else{
					nextmaze = 0;
				}
			}else{
				currentmaze = 0;
				nextmaze ++;
			}
			worldani = true;
			worldanisize = getWidth();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_D){
			right = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_A){
			left = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_W){
			up = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_S){
			down = false;
		}
		if(e.getKeyCode() == KeyEvent.VK_SHIFT){
			peek = false;
//			maze.get(nextmaze).peeksize = 0;
		}
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if(titlenum+1>=title.length){
			next = true;
		}else{
			titlenum++;
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		
	}
	
}
