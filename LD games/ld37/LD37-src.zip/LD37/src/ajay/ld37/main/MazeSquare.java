package ajay.ld37.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class MazeSquare {
	int x,y;
	int size = 64;
	
	ArrayList<MazeSquare> connected = new ArrayList<>();
	
	Color peek = new Color(255,0,0);
	
//	boolean right,left,top,bottom;
	boolean exits[] = new boolean[4];
	public MazeSquare(int x, int y){
//		this.right = right;
//		this.left = left;
//		this.up = up;
//		this.down = down;
		this.x = x;
		this.y = y;
	}
	
	public void render(Graphics g){
		int x = this.x*size;
		int y = this.y*size;
		g.setColor(Color.black);
		if(!exits[2]) g.drawLine(x, y, x+size, y);//top
		if(!exits[3]) g.drawLine(x, y+size, x+size, y+size);//bottom
		if(!exits[0]) g.drawLine(x+size, y, x+size, y+size);//right
		if(!exits[1]) g.drawLine(x, y, x, y+size);//left
	}
	
	public void peek(Graphics g, Screen screen){
		int x = this.x*size+(int) (-screen.player.x+screen.getWidth()/2+screen.player.image.getWidth()/2);
		int y = this.y*size+(int) (-screen.player.y+screen.getHeight()/2+screen.player.image.getHeight()/2);
		g.setColor(peek);
		if(!exits[2]) g.drawLine(x, y, x+size, y);//top
		if(!exits[3]) g.drawLine(x, y+size, x+size, y+size);//bottom
		if(!exits[0]) g.drawLine(x+size, y, x+size, y+size);//right
		if(!exits[1]) g.drawLine(x, y, x, y+size);//left
	}
}
