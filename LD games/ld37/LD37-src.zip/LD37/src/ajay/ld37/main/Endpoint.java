package ajay.ld37.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Endpoint {
	int x,y;
	int size = 64;
	
	BufferedImage image;
	
	public Endpoint(int x, int y){
		this.x = x;
		this.y = y;
		
		try {
			image = ImageIO.read(Screen.class.getResourceAsStream("/res/flag.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void render(Graphics g){
		int x = this.x*64;
		int y = this.y*64;
		g.drawImage(image, x+1, y+1, null);
	}
	
	public boolean isTouching(Screen screen){
		int x = this.x*64;
		int y = this.y*64;
		if(x+size > screen.player.x && x < screen.player.x+screen.player.image.getWidth() && y+size>screen.player.y && y<screen.player.y+screen.player.image.getHeight()){
			return true;
		}
		
		return false;
	}
}
