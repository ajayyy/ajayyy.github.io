package ajay.ld37.main;

import java.awt.Dimension;

import javax.swing.JFrame;

public class Main extends JFrame{
	private static final long serialVersionUID = 1484643694107322081L;
	public static void main(String[] args){
		new Main();
	}
	public Main(){
		this.setTitle("The Next Dimension");
		this.setSize(992,672);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		Screen screen = new Screen();
		screen.setPreferredSize(new Dimension(992,672));
		this.add(screen);
		this.addKeyListener(screen);
		this.addMouseListener(screen);
		this.pack();
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		screen.init();
	}
}
