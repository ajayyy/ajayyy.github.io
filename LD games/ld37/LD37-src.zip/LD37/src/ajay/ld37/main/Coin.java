package ajay.ld37.main;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Coin {
	int x,y;
	
	int size = 32;
	
	public Coin(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public void render(Graphics g, BufferedImage coin){
		int x = this.x*64;
		int y = this.y*64;
		
		g.drawImage(coin, x+16, y+16, null);
	}
	
	public boolean isTouching(Screen screen){
		int x = this.x*64+16;
		int y = this.y*64+16;
		
		if(x+size > screen.player.x && x < screen.player.x+screen.player.image.getWidth() && y+size>screen.player.y && y<screen.player.y+screen.player.image.getHeight()){
			return true;
		}
		
		return false;
	}
}
