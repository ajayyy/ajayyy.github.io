package ajay.ld37.main;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Player {
	float x,y;
	
	float speed = 3.0f;
	
	BufferedImage image;
	Rectangle rect;
	
	BufferedImage[] images = new BufferedImage[7];
	int imagenum;
	long last;
	
	public Player(Screen screen){
		try {
			image = ImageIO.read(Player.class.getResourceAsStream("/res/player.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		x = screen.getWidth()/2-image.getWidth()/2-2;
		y = screen.getHeight()/2-image.getHeight()/2+2;//TODO UP NEXT, MAKE THE SECOND BIGGEST HAVE A RANDOM POINT A LITTLE FAR AWAY BE THE BIGGEST POINT ON THE NEXT MAZE
		
		rect = new Rectangle((int) x, (int) y,image.getWidth(),image.getHeight());
		
		for(int i=0;i<images.length;i++){
			try {
				images[i] = ImageIO.read(Player.class.getResourceAsStream("/res/player_" + i + ".png"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		last = System.nanoTime();
	}
	
	public void render(Graphics g){
		g.drawImage(images[imagenum], (int) x, (int) y, null);
	}
	
	public void update(Screen screen){
		
		if(System.nanoTime() - last >= 142857142){
			imagenum++;
			if(imagenum >= images.length){
				imagenum = 0;
			}
			
			last = System.nanoTime();
		}
		
		if(screen.right){
			x += speed * screen.delta;
			if(!canMove(screen, (int) x, (int) y, screen.currentmaze)) x -= speed * screen.delta;
		}
		if(screen.left ){
			x -= speed * screen.delta;
			if(!canMove(screen, (int) x, (int) y, screen.currentmaze)) x += speed * screen.delta;
		}
		if(screen.up){
			y -= speed * screen.delta;
			if(!canMove(screen, (int) x, (int) y, screen.currentmaze)) y += speed * screen.delta;
		}
		if(screen.down){
			y += speed * screen.delta;
			if(!canMove(screen, (int) x, (int) y, screen.currentmaze)) y -= speed * screen.delta;
		}
		
		
	}
	
	public boolean canMove(Screen screen, int x, int y, int maze){
		boolean canMove = true;
		rect.setLocation((int) x, (int) y);
		for(int x1=-2;x1<=4;x1++){
			for(int y1=-2;y1<=4;y1++){
				if(((int)(y)/64+y1) < 0 || ((int)(y)/64+y1) >= screen.getHeight()/32 || ((int)(x)/64+x1) < 0 || ((int)(x)/64+x1) >= screen.getWidth()/32) continue;
				MazeSquare square = screen.maze.get(maze).squares.get(((int)(y)/64+y1)+((int)(x)/64+x1)*(screen.getHeight()/32));
				for(int i=0;i<square.exits.length;i++){
					if(!square.exits[i]){
						int[] movement = Maze.getLine(square.x, square.y, i);
						Line2D l = new Line2D.Float(movement[0]*64,movement[1]*64,movement[2]*64,movement[3]*64);
						if(rect.intersectsLine(l)){
							
							int[] playermovement = Maze.move(0, 0, i);
							x -= playermovement[0] * speed * screen.delta;
							y -= playermovement[1] * speed * screen.delta;
							
							canMove = false;
							
							break;
						}
					}
				}
				if(!canMove) break;
			}
			if(!canMove) break;

		}
		
		return canMove;
	}
}
