package ajay.ld37.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Maze{
	ArrayList<MazeSquare> squares = new ArrayList<>();
	static Random rand = new Random();
	
	BufferedImage coinimage;
	
	Color peek = new Color(0,100,20,160);
	
	boolean peekanidone;
	long peekanilast;
	float peeksize;
	
	
	public Maze(Screen screen){
//		segments.add(new MazeSegment(0, screen.getHeight()/2-16, screen.getWidth(), 32));
		squares = generate(screen);
		while(getNLongestChain(squares, 2).size()<30){
			squares = generate(screen);
		}
		
		System.out.println(getNLongestChain(squares, 1).size());
		System.out.println(getNLongestChain(squares, 2).size());
		System.out.println(getNLongestChain(squares, 3).size());
		System.out.println(getNLongestChain(squares, 4).size());
		System.out.println(getNLongestChain(squares, 5).size());
		System.out.println(getNLongestChain(squares, 6).size());
		System.out.println(getNLongestChain(squares, 7).size());
		
		try {
			coinimage = ImageIO.read(Maze.class.getResourceAsStream("/res/coin.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void render(Graphics g, Screen screen){
		for(MazeSquare square: squares){
			square.render(g);
		}
		for(Coin coin: screen.coins){
			coin.render(g, coinimage);
		}
	}
	
	public void closepeek(Graphics g, Screen screen){
		if(peeksize>0){
			g.setColor(peek);
			g.fillRect((int) (screen.getWidth()/2-peeksize/2), 0, (int) peeksize, screen.getHeight());
			peeksize-=150*screen.delta;
		}
	}
	
	public void peek(Graphics g, Screen screen){
		g.setColor(peek);
		g.fillRect((int) (screen.getWidth()/2-peeksize/2), 0, (int) peeksize, screen.getHeight());
		if(peeksize<screen.getWidth()) peeksize+=150*screen.delta;
		else{
			for(MazeSquare square: squares){
				square.peek(g, screen);
			}
		}
	}
	
	public void update(Screen screen){
		for(Coin coin: screen.coins){
			if(coin.isTouching(screen)){
				screen.coins.remove(coin);
				screen.coinamount++;
				new Thread(new Runnable() {
					  // The wrapper thread is unnecessary, unless it blocks on the
					  // Clip finishing; see comments.
					    public void run() {
					      try {
					        Clip clip = AudioSystem.getClip();
					        AudioInputStream inputStream = AudioSystem.getAudioInputStream(
					          Main.class.getResourceAsStream("/res/Pickup_Coin3.wav"));
					        clip.open(inputStream);
					        clip.start(); 
					      } catch (Exception e) {
					        System.err.println(e.getMessage());
					      }
					    }
				  }).start();
				break;
			}
		}
		
		if(screen.endpoint.isTouching(screen)){
			ArrayList<MazeSquare> connected = getConnected(squares.get(screen.endpoint.x + screen.endpoint.y * (screen.getHeight()/32)));
			MazeSquare next = connected.get(rand.nextInt(connected.size()));
			int amountofloops = rand.nextInt(3)+4;
			for(int i=0;i<amountofloops;i++){
				connected = getConnected(screen.maze.get(rand.nextInt(screen.maze.size())).squares.get(next.x + next.y * screen.getHeight()/32));
				next = connected.get(rand.nextInt(connected.size()));
			}
			screen.endpoint = new Endpoint(next.x, next.y);
			screen.checkpoints++;
			screen.checkpointangle = 0;
			new Thread(new Runnable() {
				  // The wrapper thread is unnecessary, unless it blocks on the
				  // Clip finishing; see comments.
				    public void run() {
				      try {
				        Clip clip = AudioSystem.getClip();
				        AudioInputStream inputStream = AudioSystem.getAudioInputStream(
				          Main.class.getResourceAsStream("/res/Powerup3.wav"));
				        clip.open(inputStream);
				        clip.start(); 
				      } catch (Exception e) {
				        System.err.println(e.getMessage());
				      }
				    }
			  }).start();
		}
	}
	
	public static ArrayList<MazeSquare> generate(Screen screen){
		ArrayList<MazeSquare> squares = new ArrayList<>();
		
		for(int x=0;x<screen.getWidth()/32;x++){//get(y+x*screen.getHeight()/32)
			for(int y=0;y<screen.getHeight()/32;y++){
				squares.add(new MazeSquare(x,y));
			}
		}
		
		int width = screen.getWidth()/32;
		int height = screen.getHeight()/32;
		
		int x = -1;
		int y = -1;//the x and y of the generator (it will move around to generate in different areas
		
		int oexit = -1;
		while(notAllExits(squares)){
			if(x==-1 && y==-1){
				x = width/2;
				y = height/2;
			}else{
				x = rand.nextInt(width);
				y = rand.nextInt(height);
				while(hasExits(squares, x, y, width, height)){
					x = rand.nextInt(width);
					y = rand.nextInt(height);
				}
			}
			for(int i=0;i<50;i++){
				int exit = rand.nextInt(4);
//				System.out.println(x + "  " + y + "    " + exit);
				if(oexit<0) oexit = exit;
				squares.get(y+x*height).exits[exit] = true;
				x = move(x, y, exit)[0];
				y = move(x, y, exit)[1];
				if(x>=width || x<0 || y>=height || y<0) break;
				squares.get(move(x, y, oppositeExit(exit))[1]+move(x, y, oppositeExit(exit))[0]*height).connected.add(squares.get(y+x*height));
				squares.get(y+x*height).exits[oppositeExit(exit)] = true;
				squares.get(y+x*height).connected.add(squares.get(move(x, y, oppositeExit(exit))[1]+move(x, y, oppositeExit(exit))[0]*height));
				oexit = exit;
				double randomnum = rand.nextDouble();
				if(hasExits(squares, x, y, width, height)){
					x = move(x, y, oppositeExit(exit))[0];
					y = move(x, y, oppositeExit(exit))[1];
					for(int i1=0;i1<4;i1++){
						int nx = move(x, y, i1)[0];
						int ny = move(x, y, i1)[1];
						if(nx>=width || nx<0 || ny>=height || ny<0) continue;
						if(hasExits(squares, nx, ny, width, height)){
							x = move(x, y, i1)[0];
							y = move(x, y, i1)[1];
							oexit = i1;
							exit = i1;
							break;
						}
					}
				}
				while(hasExits(squares, x, y, width, height) && randomnum > 0.5 && notAllExits(squares)){
					x = rand.nextInt(width);
					y = rand.nextInt(height);
				}
			}
			
			for(MazeSquare square: squares){
				int amount = 0;
				for(int i=0;i<square.exits.length;i++){
					if(!square.exits[i]) amount++;
				}
				if(amount == 1){
					for(int i=0;i<square.exits.length;i++){
						square.exits[i] = true;
					}
				}
			}
		}
		return squares;
		
	}
	
	public static boolean notAllExits(ArrayList<MazeSquare> squares){
		for(MazeSquare square: squares){
			boolean hasExit = false;
			for(int i=0;i<square.exits.length;i++){
				if(square.exits[i]){
					hasExit = true;
					break;
				}
			}
			if(!hasExit){
				return true;
			}
		}
		
		return false;
	}
	
	public static boolean hasExits(ArrayList<MazeSquare> squares, int x, int y, int width, int height){
		for(int i=0;i<squares.get(y+x*height).exits.length;i++){
			if(squares.get(y+x*height).exits[i] && !(move(x, y, i)[0]>=width || move(x, y, i)[0]<0 || move(x, y, i)[1]>=height || move(x, y, i)[1]<0)){
				return true;
			}
		}
		
		return false;
	}
	
	public static int oppositeExit(int exit){
		if(exit == 0 || exit == 2){
			return exit + 1;
		}else{
			return exit - 1;
		}
	}
	
	public static int[] move(int x, int y, int dir){
		switch(dir){
		case 0:
			x++;
			break;
		case 1:
			x--;
			break;
		case 2:
			y--;
			break;
		case 3:
			y++;
			break;
		}
		return new int[] {x,y};
	}
	
	public static int[] getLine(int x, int y, int dir){
		switch(dir){
			case 0:
				return new int[] {x+1,y,x+1,y+1};
			case 1:
				return new int[] {x,y,x,y+1};
			case 2:
				return new int[] {x,y,x+1,y};
			case 3:
				return new int[] {x,y+1,x+1,y+1};
		}
		return null;
	}
	
	public static ArrayList<MazeSquare> getConnected(MazeSquare square1){
		
		ArrayList<MazeSquare> connected = new ArrayList<>();
		ArrayList<MazeSquare> checked = new ArrayList<>();
		
		connected.add(square1);

		while(checked.size() != connected.size()){
			for(MazeSquare square: new ArrayList<>(connected)){
				if(!checked.contains(square)){
					for(MazeSquare square2: square.connected){
						if(!connected.contains(square2)){
							connected.add(square2);
						}
					}
					checked.add(square);
				}
			}
		}
		
		return connected;
	}
	
	public static ArrayList<MazeSquare> getNLongestChain(ArrayList<MazeSquare> squares, int n){
		ArrayList<MazeSquare> used = new ArrayList<>();
		ArrayList<ArrayList<MazeSquare>> chains = new ArrayList<>();
		
		for(MazeSquare square: squares){
			if(!used.contains(square)){
				ArrayList<MazeSquare> connected = getConnected(square);
				chains.add(connected);
				for(MazeSquare connectedsquare: connected){
					if(!used.contains(connectedsquare)){
						used.add(connectedsquare);
					}
				}
			}
		}
		
		int[] amounts = new int[chains.size()];
		for(int i=0;i<chains.size();i++){
			amounts[i] = chains.get(i).size();
		}
		Arrays.sort(amounts);
		for(ArrayList<MazeSquare> chain: chains){
			if(chain.size() == amounts[chains.size()-n]){
				return chain;
			}
		}
		
		return null;
	}
	

//	@Override
//	public void run() {
//		int width = screen.getWidth()/32;
//		int height = screen.getHeight()/32;
//		
//		int x = -1;
//		int y = -1;//the x and y of the generator (it will move around to generate in different areas
//		
//		int oexit = -1;
//		while(notAllExits(squares)){
//			if(x==-1 && y==-1){
//				x = width/2;
//				y = height/2;
//			}else{
//				x = rand.nextInt(width);
//				y = rand.nextInt(height);
//				while(hasExits(squares, x, y, width, height)){
//					x = rand.nextInt(width);
//					y = rand.nextInt(height);
//				}
//			}
//			for(int i=0;i<50;i++){
//				int exit = rand.nextInt(4);
////				System.out.println(x + "  " + y + "    " + exit);
//				if(oexit<0) oexit = exit;
//				squares.get(y+x*height).exits[exit] = true;
//				x = move(x, y, exit)[0];
//				y = move(x, y, exit)[1];
//				if(x>=width || x<0 || y>=height || y<0) break;
//				squares.get(move(x, y, oppositeExit(exit))[1]+move(x, y, oppositeExit(exit))[0]*height).connected.add(squares.get(y+x*height));
//				squares.get(y+x*height).exits[oppositeExit(exit)] = true;
//				squares.get(y+x*height).connected.add(squares.get(move(x, y, oppositeExit(exit))[1]+move(x, y, oppositeExit(exit))[0]*height));
//				oexit = exit;
//				try {
//					Thread.sleep(5);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
//				double randomnum = rand.nextDouble();
//				System.out.println(randomnum);
//				if(hasExits(squares, x, y, width, height)){
//					x = move(x, y, oppositeExit(exit))[0];
//					y = move(x, y, oppositeExit(exit))[1];
//					for(int i1=0;i1<4;i1++){
//						int nx = move(x, y, i1)[0];
//						int ny = move(x, y, i1)[1];
//						if(nx>=width || nx<0 || ny>=height || ny<0) continue;
//						if(hasExits(squares, nx, ny, width, height)){
//							x = move(x, y, i1)[0];
//							y = move(x, y, i1)[1];
//							oexit = i1;
//							exit = i1;
//							break;
//						}
//					}
//				}
//				while(hasExits(squares, x, y, width, height) && randomnum > 0.7){
//					x = rand.nextInt(width);
//					y = rand.nextInt(height);
//				}
//			}
//			
//			for(MazeSquare square: squares){
//				int amount = 0;
//				for(int i=0;i<square.exits.length;i++){
//					if(!square.exits[i]) amount++;
//				}
//				if(amount == 1){
//					for(int i=0;i<square.exits.length;i++){
//						square.exits[i] = true;
//					}
//				}
//			}
//		}
//	}
}
