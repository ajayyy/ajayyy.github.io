package ajay.ld38.main;

public class Shape {//maybe tetris shapes
	public Shape(){
		
	}
}
