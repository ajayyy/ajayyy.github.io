package ajay.ld38.main;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Stroke;

public class Wall {
	int x,y,endx,endy;
	int color;
	public Wall(int x, int y, int endx, int endy, int color){
		this.x = x;
		this.y = y;
		this.endx = endx;
		this.endy = endy;
		this.color = color;
	}
	
	public void render(Logic logic, Graphics2D g){
		g.setColor(logic.getColor(color));
		Stroke oldStroke = g.getStroke();
		g.setStroke(new BasicStroke(4));
		g.drawLine(logic.paddingleft + x*logic.level.blockwidth, logic.paddingtop + y*logic.level.blockheight, logic.paddingleft + (endx)*logic.level.blockwidth, logic.paddingtop + (endy)*logic.level.blockheight);
		g.setStroke(oldStroke);
	}
}